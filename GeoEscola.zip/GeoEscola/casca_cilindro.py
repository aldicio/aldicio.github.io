import adsk.core, adsk.fusion, traceback
import math

# Lista global para manter os handlers vivos
_handlers = []

def run_casca_cilindro():
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        cmd_id = 'cmd_casca_cilindro_angular'
        cmd_def = ui.commandDefinitions.itemById(cmd_id)
        if cmd_def: cmd_def.deleteMe() 
        
        cmd_def = ui.commandDefinitions.addButtonDefinition(
            cmd_id, 
            'Casca de Cilindro Angular', 
            'Gera cilindro oco baseado em dimensões internas'
        )
        
        on_created = CascaCilindroCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        cmd_def.execute()
    except:
        ui.messageBox('Erro: {}'.format(traceback.format_exc()))

class CascaCilindroCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            
            # Entradas de dimensões INTERNAS
            inputs.addValueInput('r_int', 'Raio interno', 'mm', adsk.core.ValueInput.createByReal(3.0))
            inputs.addValueInput('h_int', 'Altura', 'mm', adsk.core.ValueInput.createByReal(5.0))
            inputs.addValueInput('espessura', 'Espessura', 'mm', adsk.core.ValueInput.createByReal(0.3))
            
            # Slider de Ângulo (usando a lógica de 0 a 2*PI)
            angle_slider = inputs.addFloatSliderCommandInput('angulo', 'Ângulo de abertura', 'deg', 0.0, 2 * math.pi, False)
            angle_slider.valueOne = 2 * math.pi 

            on_execute = CascaCilindroExecuteHandler()
            args.command.execute.add(on_execute)
            _handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox(traceback.format_exc())

class CascaCilindroExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            inps = args.command.commandInputs
            
            ri = inps.itemById('r_int').value
            hi = inps.itemById('h_int').value
            d = inps.itemById('espessura').value
            angulo_rad = inps.itemById('angulo').valueOne 

            design = adsk.fusion.Design.cast(app.activeProduct)
            root = design.rootComponent
            
            re = ri + d # Raio externo simples (sem inclinação)

            # --- 1. CRIAR SKETCH DO PERFIL (PLANO XY) ---
            sk = root.sketches.add(root.xYConstructionPlane)
            lines = sk.sketchCurves.sketchLines
            
            # Retângulo da parede lateral
            p1 = adsk.core.Point3D.create(ri, 0, 0)
            p2 = adsk.core.Point3D.create(re, 0, 0)
            p3 = adsk.core.Point3D.create(re, hi, 0)
            p4 = adsk.core.Point3D.create(ri, hi, 0)
            
            lines.addByTwoPoints(p1, p2)
            lines.addByTwoPoints(p2, p3)
            lines.addByTwoPoints(p3, p4)
            lines.addByTwoPoints(p4, p1)

            # --- 2. CRIAR O EIXO DE ROTAÇÃO NO SKETCH ---
            eixo = lines.addByTwoPoints(adsk.core.Point3D.create(0, 0, 0), adsk.core.Point3D.create(0, hi, 0))
            eixo.isConstruction = True

            # --- 3. OPERAÇÃO DE REVOLUÇÃO ---
            if sk.profiles.count > 0:
                prof = sk.profiles.item(0)
                revolves = root.features.revolveFeatures
                rev_input = revolves.createInput(prof, eixo, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                
                rev_input.setAngleExtent(False, adsk.core.ValueInput.createByReal(angulo_rad))
                corpo = revolves.add(rev_input).bodies.item(0)
                corpo.name = "CascaCilindro_Angular"
            
        except:
            app.userInterface.messageBox('Erro na Geometria: {}'.format(traceback.format_exc()))