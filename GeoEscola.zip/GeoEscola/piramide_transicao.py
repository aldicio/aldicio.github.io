import adsk.core, adsk.fusion, traceback
import math

# Lista global para manter os handlers vivos
_handlers = []

def run_piramide():
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        cmd_id = 'cmd_piramide_transicao'
        cmd_def = ui.commandDefinitions.itemById(cmd_id)
        if cmd_def: cmd_def.deleteMe() 
        
        cmd_def = ui.commandDefinitions.addButtonDefinition(
            cmd_id, 
            'Pirâmide por Transição', 
            'Gera uma pirâmide ligando um polígono regular a um ponto P'
        )
        
        on_created = PiramideCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        
        cmd_def.execute()
    except:
        ui.messageBox('Erro ao iniciar Pirâmide: {}'.format(traceback.format_exc()))

class PiramideCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            
            # 1. Parâmetros da Base Poligonal (Lógica do prisma.py)
            inputs.addIntegerSliderCommandInput('n_lados', 'Número de arestas da base', 3, 100)
            
            modo = inputs.addDropDownCommandInput('modo_calculo', 'Definir base por:', adsk.core.DropDownStyles.TextListDropDownStyle)
            modo.listItems.add('Raio circunscrito', True)
            modo.listItems.add('Comprimento da aresta', False)
            
            inputs.addValueInput('valor_medida', 'Medida da base', 'mm', adsk.core.ValueInput.createByReal(2.5))

            # 2. Coordenadas do Vértice (Ponto P)
            grp = inputs.addGroupCommandInput('grpPontoP', 'Coordenadas do vértice')
            inputs.addValueInput('pontoX', 'Vértice: X', 'mm', adsk.core.ValueInput.createByReal(0.0))
            inputs.addValueInput('pontoY', 'Vértice: Y', 'mm', adsk.core.ValueInput.createByReal(0.0))
            inputs.addValueInput('pontoZ', 'Vértice: Z / Altura', 'mm', adsk.core.ValueInput.createByReal(5.0))

            on_execute = PiramideExecuteHandler()
            args.command.execute.add(on_execute)
            _handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na interface: {}'.format(traceback.format_exc()))

class PiramideExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            inputs = args.command.commandInputs

            # Captura dos valores
            n = inputs.itemById('n_lados').valueOne
            modo = inputs.itemById('modo_calculo').selectedItem.name
            medida = inputs.itemById('valor_medida').value
            pX = inputs.itemById('pontoX').value
            pY = inputs.itemById('pontoY').value
            pZ = inputs.itemById('pontoZ').value

            # Cálculo do Raio (Lógica do prisma.py)
            if modo == 'Comprimento Aresta':
                raio = medida / (2 * math.sin(math.pi / n))
            else:
                raio = medida

            design = adsk.fusion.Design.cast(app.activeProduct)
            root = design.rootComponent
            
            # 1. Criar o Sketch da Base Poligonal
            sketchBase = root.sketches.add(root.xYConstructionPlane)
            lines = sketchBase.sketchCurves.sketchLines
            vertices = []
            for i in range(n):
                angulo = (2 * math.pi * i / n) + (math.pi / 2)
                x = raio * math.cos(angulo)
                y = raio * math.sin(angulo)
                vertices.append(adsk.core.Point3D.create(x, y, 0))

            for i in range(n):
                lines.addByTwoPoints(vertices[i], vertices[(i + 1) % n])
            
            # 2. Criar o Sketch do Vértice (Ponto P)
            sketchPonto = root.sketches.add(root.xYConstructionPlane)
            pontoP = sketchPonto.sketchPoints.add(adsk.core.Point3D.create(pX, pY, pZ))

            # 3. Executar o Loft (Transição)
            if sketchBase.profiles.count > 0:
                profBase = sketchBase.profiles.item(0)
                lofts = root.features.loftFeatures
                loftInput = lofts.createInput(adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                loftInput.loftSections.add(profBase)
                loftInput.loftSections.add(pontoP)
                lofts.add(loftInput)
            else:
                app.userInterface.messageBox('Erro: Perfil da base não identificado.')
            
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na Geometria: {}'.format(traceback.format_exc()))