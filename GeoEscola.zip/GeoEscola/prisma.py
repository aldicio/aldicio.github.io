import adsk.core, adsk.fusion, traceback
import math

# Lista global para manter os handlers vivos
_handlers = []

def run_prisma():
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        cmd_id = 'cmd_prisma_final'
        cmd_def = ui.commandDefinitions.itemById(cmd_id)
        if cmd_def: cmd_def.deleteMe() 
        
        cmd_def = ui.commandDefinitions.addButtonDefinition(cmd_id, 'Prisma Regular', 'Gera um prisma reto customizado')
        
        on_created = PrismaCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        
        cmd_def.execute()
    except:
        ui.messageBox('Erro ao iniciar Prisma: {}'.format(traceback.format_exc()))

class PrismaCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            
            # 1. Quantidade de lados (Vértices)
            inputs.addIntegerSliderCommandInput('n_lados', 'Número de arestas da base', 3, 100)
            
            # 2. Seletor de modo (DropDown estável)
            modo = inputs.addDropDownCommandInput('modo_calculo', 'Definir base por:', adsk.core.DropDownStyles.TextListDropDownStyle)
            modo.listItems.add('Raio circunscrito', True)
            modo.listItems.add('Comprimento da aresta', False)
            
            # 3. Valor da Medida da Base (mm)
            inputs.addValueInput('valor_medida', 'Medida da Base', 'mm', adsk.core.ValueInput.createByReal(2.0))
            
            # 4. Altura do Prisma (mm) - NOVO CAMPO
            inputs.addValueInput('altura', 'Altura do Prisma', 'mm', adsk.core.ValueInput.createByReal(5.0))

            on_execute = PrismaExecuteHandler()
            args.command.execute.add(on_execute)
            _handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na interface: {}'.format(traceback.format_exc()))

class PrismaExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            inputs = args.command.commandInputs

            # Captura dos valores
            n = inputs.itemById('n_lados').valueOne
            modo = inputs.itemById('modo_calculo').selectedItem.name
            medida = inputs.itemById('valor_medida').value
            h = inputs.itemById('altura').value

            # Cálculo do Raio
            if modo == 'Comprimento Aresta':
                raio = medida / (2 * math.sin(math.pi / n))
            else:
                raio = medida

            design = adsk.fusion.Design.cast(app.activeProduct)
            root = design.rootComponent
            
            # 1. Criar o Sketch no Plano XY
            sketch = root.sketches.add(root.xYConstructionPlane)
            lines = sketch.sketchCurves.sketchLines

            # 2. Desenhar a base ponto a ponto (Trigonometria)
            vertices = []
            for i in range(n):
                angulo = (2 * math.pi * i / n) + (math.pi / 2)
                x = raio * math.cos(angulo)
                y = raio * math.sin(angulo)
                vertices.append(adsk.core.Point3D.create(x, y, 0))

            for i in range(n):
                p1 = vertices[i]
                p2 = vertices[(i + 1) % n]
                lines.addByTwoPoints(p1, p2)
            
            # 3. Extrusão do perfil criado
            if sketch.profiles.count > 0:
                prof = sketch.profiles.item(0)
                exts = root.features.extrudeFeatures
                ext_input = exts.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                ext_input.setDistanceExtent(False, adsk.core.ValueInput.createByReal(h))
                exts.add(ext_input)
            else:
                app.userInterface.messageBox('Erro: Não foi possível identificar o perfil da base.')
            
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na Geometria: {}'.format(traceback.format_exc()))