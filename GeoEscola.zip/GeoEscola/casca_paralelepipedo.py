import adsk.core, adsk.fusion, traceback

# Lista global para manter os handlers vivos
_handlers = []

def run_casca_para():
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        cmd_id = 'cmd_casca_paralelepipedo'
        cmd_def = ui.commandDefinitions.itemById(cmd_id)
        if cmd_def: cmd_def.deleteMe() 
        
        cmd_def = ui.commandDefinitions.addButtonDefinition(
            cmd_id, 
            'Casca de Paralelepípedo', 
            'Gera um bloco retangular oco com espessuras personalizadas'
        )
        
        on_created = CascaParaCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        
        cmd_def.execute()
    except:
        ui.messageBox('Erro ao iniciar Casca de Paralelepípedo: {}'.format(traceback.format_exc()))

class CascaParaCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            
            # 1. Dimensões Externas
            inputs.addValueInput('largura', 'Largura: X', 'mm', adsk.core.ValueInput.createByReal(2.0))
            inputs.addValueInput('comprimento', 'Comprimento: Y', 'mm', adsk.core.ValueInput.createByReal(3.0))
            inputs.addValueInput('altura', 'Altura: Z', 'mm', adsk.core.ValueInput.createByReal(4.0))

            # 2. Espessuras
            inputs.addValueInput('esp_parede', 'Espessura da parede', 'mm', adsk.core.ValueInput.createByReal(0.2))
            inputs.addValueInput('esp_fundo', 'Espessura do fundo', 'mm', adsk.core.ValueInput.createByReal(0.3))
            inputs.addValueInput('esp_tampa', 'Espessura da tampa', 'mm', adsk.core.ValueInput.createByReal(0.3))

            on_execute = CascaParaExecuteHandler()
            args.command.execute.add(on_execute)
            _handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na interface: {}'.format(traceback.format_exc()))

class CascaParaExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            inps = args.command.commandInputs

            # Captura de valores
            lx = inps.itemById('largura').value
            ly = inps.itemById('comprimento').value
            lz = inps.itemById('altura').value
            ep = inps.itemById('esp_parede').value
            ef = inps.itemById('esp_fundo').value
            et = inps.itemById('esp_tampa').value

            design = adsk.fusion.Design.cast(app.activeProduct)
            root = design.rootComponent
            feats = root.features

            # --- 1. CRIAR BLOCO EXTERNO ---
            sk_ext = root.sketches.add(root.xYConstructionPlane)
            # Desenha retângulo centralizado na origem
            sk_ext.sketchCurves.sketchLines.addCenterPointRectangle(adsk.core.Point3D.create(0,0,0), adsk.core.Point3D.create(lx/2, ly/2, 0))
            
            prof_ext = sk_ext.profiles.item(0)
            ext_input_ext = feats.extrudeFeatures.createInput(prof_ext, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            ext_input_ext.setDistanceExtent(False, adsk.core.ValueInput.createByReal(lz))
            corpo_bloco = feats.extrudeFeatures.add(ext_input_ext).bodies.item(0)
            corpo_bloco.name = "Casca_Paralelepipedo"

            # --- 2. OPERAÇÃO DE SUBTRAÇÃO (CASCA) ---
            if ep > 0:
                # Dimensões internas
                lxi = lx - (2 * ep)
                lyi = ly - (2 * ep)
                lzi = lz - ef - et

                if lxi <= 0 or lyi <= 0 or lzi <= 0:
                    app.userInterface.messageBox('Erro: Espessuras maiores que as dimensões externas.')
                    return

                # Criar o Bloco Interno (o "vazio")
                sk_int = root.sketches.add(root.xYConstructionPlane)
                sk_int.sketchCurves.sketchLines.addCenterPointRectangle(adsk.core.Point3D.create(0,0,0), adsk.core.Point3D.create(lxi/2, lyi/2, 0))
                
                prof_int = sk_int.profiles.item(0)
                ext_input_int = feats.extrudeFeatures.createInput(prof_int, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                
                # Início deslocado pelo fundo
                offset_fundo = adsk.core.ValueInput.createByReal(ef)
                ext_input_int.startExtent = adsk.fusion.OffsetStartDefinition.create(offset_fundo)
                ext_input_int.setDistanceExtent(False, adsk.core.ValueInput.createByReal(lzi))
                
                corpo_interno = feats.extrudeFeatures.add(ext_input_int).bodies.item(0)

                # Subtrair do bloco principal
                tools = adsk.core.ObjectCollection.create()
                tools.add(corpo_interno)
                comb_input = feats.combineFeatures.createInput(corpo_bloco, tools)
                comb_input.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
                feats.combineFeatures.add(comb_input)

        except:
            app.userInterface.messageBox(traceback.format_exc())