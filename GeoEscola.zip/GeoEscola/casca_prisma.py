import adsk.core, adsk.fusion, traceback
import math

# Lista global para manter os handlers vivos
_handlers = []

def run_casca_prisma():
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        cmd_id = 'cmd_casca_prisma'
        cmd_def = ui.commandDefinitions.itemById(cmd_id)
        if cmd_def: cmd_def.deleteMe() 
        
        cmd_def = ui.commandDefinitions.addButtonDefinition(
            cmd_id, 
            'Casca de Prisma', 
            'Gera um prisma oco com base poligonal regular'
        )
        
        on_created = CascaPrismaCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        
        cmd_def.execute()
    except:
        ui.messageBox('Erro ao iniciar Casca de Prisma: {}'.format(traceback.format_exc()))

class CascaPrismaCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            
            # 1. Definição da Geometria do Polígono
            inputs.addIntegerSliderCommandInput('n_lados', 'Número de arestas da base', 3, 100)
            
            modo = inputs.addDropDownCommandInput('modo_calculo', 'Definir base por:', adsk.core.DropDownStyles.TextListDropDownStyle)
            modo.listItems.add('Raio Circunscrito', True)
            modo.listItems.add('Comprimento Aresta', False)
            
            inputs.addValueInput('valor_medida', 'Medida da base', 'mm', adsk.core.ValueInput.createByReal(3.0))
            inputs.addValueInput('altura', 'Altura', 'mm', adsk.core.ValueInput.createByReal(5.0))

            # 2. Definição das Espessuras
            inputs.addValueInput('esp_parede', 'Espessura da parede', 'mm', adsk.core.ValueInput.createByReal(0.2))
            inputs.addValueInput('esp_base', 'Espessura do fundo', 'mm', adsk.core.ValueInput.createByReal(0.3))
            inputs.addValueInput('esp_tampa', 'Espessura da tampa', 'mm', adsk.core.ValueInput.createByReal(0.3))

            on_execute = CascaPrismaExecuteHandler()
            args.command.execute.add(on_execute)
            _handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na interface: {}'.format(traceback.format_exc()))

class CascaPrismaExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            inps = args.command.commandInputs

            # Captura de valores
            n = inps.itemById('n_lados').valueOne
            modo = inps.itemById('modo_calculo').selectedItem.name
            medida = inps.itemById('valor_medida').value
            h_total = inps.itemById('altura').value
            e_p = inps.itemById('esp_parede').value
            e_b = inps.itemById('esp_base').value
            e_t = inps.itemById('esp_tampa').value

            # Cálculo do Raio Externo (Lógica do prisma.py)
            if modo == 'Comprimento Aresta':
                raio_ext = medida / (2 * math.sin(math.pi / n))
            else:
                raio_ext = medida

            design = adsk.fusion.Design.cast(app.activeProduct)
            root = design.rootComponent
            feats = root.features

            # --- 1. CRIAR PRISMA EXTERNO ---
            sk_ext = root.sketches.add(root.xYConstructionPlane)
            pts_ext = []
            for i in range(n):
                ang = (2 * math.pi * i / n) + (math.pi / 2)
                pts_ext.append(adsk.core.Point3D.create(raio_ext * math.cos(ang), raio_ext * math.sin(ang), 0))
            for i in range(n):
                sk_ext.sketchCurves.sketchLines.addByTwoPoints(pts_ext[i], pts_ext[(i + 1) % n])
            
            prof_ext = sk_ext.profiles.item(0)
            ext_input_ext = feats.extrudeFeatures.createInput(prof_ext, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            ext_input_ext.setDistanceExtent(False, adsk.core.ValueInput.createByReal(h_total))
            corpo_prisma = feats.extrudeFeatures.add(ext_input_ext).bodies.item(0)

            # --- 2. OPERAÇÃO DE CASCA (CONDICIONAL) ---
            if e_p > 0:
                # Cálculo do Raio Interno (Mantendo a distância perpendicular e_p)
                # No polígono, a distância do centro ao lado (apótema) diminui e_p
                apotema_ext = raio_ext * math.cos(math.pi / n)
                apotema_int = apotema_ext - e_p
                raio_int = apotema_int / math.cos(math.pi / n)

                if raio_int <= 0 or (h_total - e_b - e_t) <= 0:
                    app.userInterface.messageBox('Espessura muito grande para as dimensões da base.')
                    return

                # Criar o Prisma Interno para Subtração
                sk_int = root.sketches.add(root.xYConstructionPlane)
                pts_int = []
                for i in range(n):
                    ang = (2 * math.pi * i / n) + (math.pi / 2)
                    pts_int.append(adsk.core.Point3D.create(raio_int * math.cos(ang), raio_int * math.sin(ang), 0))
                for i in range(n):
                    sk_int.sketchCurves.sketchLines.addByTwoPoints(pts_int[i], pts_int[(i + 1) % n])
                
                prof_int = sk_int.profiles.item(0)
                ext_input_int = feats.extrudeFeatures.createInput(prof_int, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                
                # Início com offset (Espessura da Base)
                offset_base = adsk.core.ValueInput.createByReal(e_b)
                ext_input_int.startExtent = adsk.fusion.OffsetStartDefinition.create(offset_base)
                
                # Altura interna = h_total - e_base - e_tampa
                h_int = h_total - e_b - e_t
                ext_input_int.setDistanceExtent(False, adsk.core.ValueInput.createByReal(h_int))
                
                corpo_interno = feats.extrudeFeatures.add(ext_input_int).bodies.item(0)

                # Subtração
                tools = adsk.core.ObjectCollection.create()
                tools.add(corpo_interno)
                comb_input = feats.combineFeatures.createInput(corpo_prisma, tools)
                comb_input.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
                feats.combineFeatures.add(comb_input)

        except:
            app.userInterface.messageBox(traceback.format_exc())