import adsk.core, adsk.fusion, traceback
import math

# Lista global para manter os handlers vivos
_handlers = []

def run_cone_transicao():
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        cmd_id = 'cmd_cone_transicao'
        cmd_def = ui.commandDefinitions.itemById(cmd_id)
        if cmd_def: cmd_def.deleteMe() 
        
        cmd_def = ui.commandDefinitions.addButtonDefinition(cmd_id, 'Cone por Transição', 'Gera um cone ligando um círculo a um ponto P')
        
        on_created = ConeLoftCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        
        cmd_def.execute()
    except:
        ui.messageBox('Erro ao iniciar Cone: {}'.format(traceback.format_exc()))

class ConeLoftCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            
            # 1. Grupo Centro da Base
            inputs.addValueInput('centerX', 'Centro: X', 'mm', adsk.core.ValueInput.createByReal(0.0))
            inputs.addValueInput('centerY', 'Centro: Y', 'mm', adsk.core.ValueInput.createByReal(0.0))
            
            # 2. Raio da Base
            inputs.addValueInput('raio', 'Raio da Base', 'mm', adsk.core.ValueInput.createByReal(2.5))
            
            # 3. Coordenadas do Vértice (Ponto P)
            inputs.addValueInput('pontoX', 'Vértice: X', 'mm', adsk.core.ValueInput.createByReal(0.0))
            inputs.addValueInput('pontoY', 'Vértice: Y', 'mm', adsk.core.ValueInput.createByReal(0.0))
            inputs.addValueInput('pontoZ', 'Vértice: Z / Altura', 'mm', adsk.core.ValueInput.createByReal(5.0))

            on_execute = ConeLoftExecuteHandler()
            args.command.execute.add(on_execute)
            _handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na interface: {}'.format(traceback.format_exc()))

class ConeLoftExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            inputs = args.command.commandInputs

            # Captura dos valores
            cX = inputs.itemById('centerX').value
            cY = inputs.itemById('centerY').value
            raio = inputs.itemById('raio').value
            pX = inputs.itemById('pontoX').value
            pY = inputs.itemById('pontoY').value
            pZ = inputs.itemById('pontoZ').value

            design = adsk.fusion.Design.cast(app.activeProduct)
            root = design.rootComponent
            
            # 1. Criar o Sketch da Base (Círculo)
            sketchBase = root.sketches.add(root.xYConstructionPlane)
            sketchBase.sketchCurves.sketchCircles.addByCenterRadius(adsk.core.Point3D.create(cX, cY, 0), raio)
            
            # 2. Criar o Sketch do Vértice (Ponto)
            sketchPonto = root.sketches.add(root.xYConstructionPlane)
            pontoP = sketchPonto.sketchPoints.add(adsk.core.Point3D.create(pX, pY, pZ))

            # 3. Executar o Loft (Transição)
            if sketchBase.profiles.count > 0:
                profBase = sketchBase.profiles.item(0)
                lofts = root.features.loftFeatures
                loftInput = lofts.createInput(adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                loftInput.loftSections.add(profBase)
                loftInput.loftSections.add(pontoP)
                lofts.add(loftInput)
            else:
                app.userInterface.messageBox('Erro: Perfil da base não encontrado.')
            
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na Geometria: {}'.format(traceback.format_exc()))