import adsk.core, adsk.fusion, traceback
import math

_handlers = []

def run_casca():
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        cmd_def = ui.commandDefinitions.itemById('cmd_casca_esf_geo')
        if cmd_def: cmd_def.deleteMe() 
        
        cmd_def = ui.commandDefinitions.addButtonDefinition('cmd_casca_esf_geo', 'Casca Esférica', 'Gera casca por subtração')
        on_created = CascaEsfericaCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        cmd_def.execute()
    except:
        ui.messageBox('Erro ao iniciar: {}'.format(traceback.format_exc()))

class CascaEsfericaCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            inputs.addValueInput('raio_menor', 'Raio interno', 'mm', adsk.core.ValueInput.createByReal(2.0))
            inputs.addValueInput('espessura', 'Espessura', 'mm', adsk.core.ValueInput.createByReal(0.5))
            inputs.addValueInput('angulo', 'Ângulo de Abertura', 'deg', adsk.core.ValueInput.createByReal(math.radians(360)))

            on_execute = CascaEsfericaExecuteHandler()
            args.command.execute.add(on_execute)
            _handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na interface: {}'.format(traceback.format_exc()))

class CascaEsfericaExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            inputs = args.command.commandInputs

            r_min = inputs.itemById('raio_menor').value
            esp = inputs.itemById('espessura').value
            r_max = r_min + esp
            angulo_rad = inputs.itemById('angulo').value

            design = adsk.fusion.Design.cast(app.activeProduct)
            root = design.rootComponent
            features = root.features
            
            # --- FUNÇÃO AUXILIAR PARA CRIAR ESFERA/FUSO ---
            def criar_esfera_base(raio, angulo):
                sk = root.sketches.add(root.xZConstructionPlane)
                center = adsk.core.Point3D.create(0, 0, 0)
                # Eixo vertical
                eixo = sk.sketchCurves.sketchLines.addByTwoPoints(
                    adsk.core.Point3D.create(0, -raio, 0), 
                    adsk.core.Point3D.create(0, raio, 0)
                )
                # Semicírculo
                arco = sk.sketchCurves.sketchArcs.addByCenterStartSweep(center, adsk.core.Point3D.create(0, raio, 0), math.pi)
                sk.sketchCurves.sketchLines.addByTwoPoints(arco.startSketchPoint, arco.endSketchPoint)
                
                prof = sk.profiles.item(0)
                revs = features.revolveFeatures
                rev_input = revs.createInput(prof, eixo, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                rev_input.setAngleExtent(False, adsk.core.ValueInput.createByReal(angulo))
                return revs.add(rev_input).bodies.item(0)

            # 1. Criar a esfera externa (Corpo Principal)
            corpo_maior = criar_esfera_base(r_max, angulo_rad)
            
            # 2. Criar a esfera interna (Corpo de Corte)
            corpo_menor = criar_esfera_base(r_min, angulo_rad)
            
            # 3. Operação Booleana de Corte (Combine)
            tool_bodies = adsk.core.ObjectCollection.create()
            tool_bodies.add(corpo_menor)
            
            combine_input = features.combineFeatures.createInput(corpo_maior, tool_bodies)
            combine_input.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
            features.combineFeatures.add(combine_input)
            
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na Geometria: {}'.format(traceback.format_exc()))