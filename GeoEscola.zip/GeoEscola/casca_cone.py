import adsk.core, adsk.fusion, traceback
import math

# Lista global para manter os handlers vivos
_handlers = []

def run_casca_cone():
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        cmd_id = 'cmd_casca_cone_angular'
        cmd_def = ui.commandDefinitions.itemById(cmd_id)
        if cmd_def: cmd_def.deleteMe() 
        
        cmd_def = ui.commandDefinitions.addButtonDefinition(
            cmd_id, 
            'Casca de Cone Angular', 
            'Gera cone oco com ângulo de abertura e espessura constante'
        )
        
        on_created = CascaConeCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        cmd_def.execute()
    except:
        ui.messageBox('Erro: {}'.format(traceback.format_exc()))

class CascaConeCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            
            # Entradas (API usa cm, interface mostra mm ou deg)
            inputs.addValueInput('r_int', 'Raio interno', 'mm', adsk.core.ValueInput.createByReal(3.0))
            inputs.addValueInput('h_int', 'Altura interna', 'mm', adsk.core.ValueInput.createByReal(5.0))
            inputs.addValueInput('espessura', 'Espessura', 'mm', adsk.core.ValueInput.createByReal(0.2))
            
            # Slider para o ângulo (usando a sua lógica de 0 a 2*PI)
            angle_slider = inputs.addFloatSliderCommandInput('angulo', 'Ângulo de abertura', 'deg', 0.0, 2 * math.pi, False)
            angle_slider.valueOne = 2 * math.pi 

            on_execute = CascaConeExecuteHandler()
            args.command.execute.add(on_execute)
            _handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na interface: {}'.format(traceback.format_exc()))

class CascaConeExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            inps = args.command.commandInputs
            
            ri = inps.itemById('r_int').value
            hi = inps.itemById('h_int').value
            d = inps.itemById('espessura').value
            angulo_rad = inps.itemById('angulo').valueOne 

            design = adsk.fusion.Design.cast(app.activeProduct)
            root = design.rootComponent
            
            # --- CÁLCULOS DA SEÇÃO TRANSVERSAL ---
            alpha = math.atan(ri / hi)
            delta_r = d / math.cos(alpha)
            delta_h = d / math.sin(alpha)
            
            re = ri + delta_r
            he = hi + delta_h

            # --- 1. CRIAR SKETCH DO PERFIL (PLANO XY) ---
            sk = root.sketches.add(root.xYConstructionPlane)
            lines = sk.sketchCurves.sketchLines
            
            # Pontos do trapézio (parede do cone)
            p1 = adsk.core.Point3D.create(ri, 0, 0)
            p2 = adsk.core.Point3D.create(re, 0, 0)
            p3 = adsk.core.Point3D.create(0, he, 0) # No plano XY, a altura é Y
            p4 = adsk.core.Point3D.create(0, hi, 0)
            
            lines.addByTwoPoints(p1, p2)
            lines.addByTwoPoints(p2, p3)
            lines.addByTwoPoints(p3, p4)
            lines.addByTwoPoints(p4, p1)

            # --- 2. CRIAR O EIXO DE ROTAÇÃO NO PRÓPRIO SKETCH ---
            # Linha que vai da base (0,0) até o topo externo (0, he)
            eixo = lines.addByTwoPoints(adsk.core.Point3D.create(0,0,0), p3)
            eixo.isConstruction = True # Define como linha de construção

            # --- 3. OPERAÇÃO DE REVOLUÇÃO ---
            if sk.profiles.count > 0:
                prof = sk.profiles.item(0)
                revolves = root.features.revolveFeatures
                rev_input = revolves.createInput(prof, eixo, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                
                angle_val = adsk.core.ValueInput.createByReal(angulo_rad)
                rev_input.setAngleExtent(False, angle_val)
                
                corpo = revolves.add(rev_input).bodies.item(0)
                corpo.name = "CascaCone_Angular"
            
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na Geometria: {}'.format(traceback.format_exc()))