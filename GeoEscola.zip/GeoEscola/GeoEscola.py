import adsk.core, adsk.fusion, traceback
import os

# Lista global para manter os botões vivos
handlers = []

# Tenta importar os arquivos. Se um falhar, ele avisa qual.
try:
    from . import paralelepipedo
    from . import casca_esferica
    from . import prisma
    from . import cone_transicao
    from . import piramide_transicao
    from . import anticlepsidra
    from . import casca_cilindro 
    from . import casca_tronco_cone
    from . import casca_prisma
    from . import casca_paralelepipedo
    from . import casca_cone
    
except:
    # Se der erro aqui, o problema está em um dos arquivos acima
    adsk.core.Application.get().userInterface.messageBox('Erro na Importação:\n{}'.format(traceback.format_exc()))

class GenericHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self, callback):
        super().__init__()
        self.callback = callback
    def notify(self, args):
        try:
            self.callback()
        except:
            adsk.core.Application.get().userInterface.messageBox(traceback.format_exc())

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        
        # --- LINHA NOVA: Localiza a pasta do script para encontrar os ícones ---
        base_path = os.path.dirname(os.path.realpath(__file__))
        
        workspace = ui.workspaces.itemById('FusionSolidEnvironment')
        solid_tab = workspace.toolbarTabs.itemById('SolidTab')
        
        # Limpar painel antigo
        old_panel = solid_tab.toolbarPanels.itemById('GeoEscolaPanel')
        if old_panel: old_panel.deleteMe()
        
        geo_panel = solid_tab.toolbarPanels.add('GeoEscolaPanel', 'GeoEscola')

        
        # --- BOTÃO ANTICLEPSIDRA ---
        cmd_anticlepsidra_id = 'btnAnticlepsidra'
        icon_anticlepsidra = os.path.join(base_path, 'resources', cmd_anticlepsidra_id)
        def_anticlep = ui.commandDefinitions.itemById(cmd_anticlepsidra_id)
        if def_anticlep: def_anticlep.deleteMe()
        cmd_anticlep = ui.commandDefinitions.addButtonDefinition(cmd_anticlepsidra_id, 'Anticlepsidra', 'Raio interno, Espessura da parede, Espessura da tampa, Espessura do fundo',icon_anticlepsidra)
        on_anticlep = GenericHandler(anticlepsidra.run_anticlepsidra)
        cmd_anticlep.commandCreated.add(on_anticlep)
        handlers.append(on_anticlep)
        geo_panel.controls.addCommand(cmd_anticlep)
        
        #-------------------------------------------------------------------------------------------------------------------------------
        
        # --- BOTÃO: PRISMA REGULAR ---
        cmd_prisma_regular_id = 'btnPrisma'
        icon_prisma_regular = os.path.join(base_path, 'resources', cmd_prisma_regular_id)
        def_prisma = ui.commandDefinitions.itemById(cmd_prisma_regular_id)
        if def_prisma: def_prisma.deleteMe()
        cmd_prisma = ui.commandDefinitions.addButtonDefinition(cmd_prisma_regular_id, 'Prisma regular', 'Núm. de arestas, Medida da base, Altura', icon_prisma_regular)
        on_prisma = GenericHandler(prisma.run_prisma)
        cmd_prisma.commandCreated.add(on_prisma)
        handlers.append(on_prisma)
        geo_panel.controls.addCommand(cmd_prisma)
        
        #-----------CONE TRANSICAO-----------------------------------------------------------------------------------------------------------------
        
        cmd_cone_id = 'btnConeTransicao'
        icon_cone = os.path.join(base_path, 'resources', cmd_cone_id)
       
        def_cone_transicao = ui.commandDefinitions.itemById(cmd_cone_id)
        if def_cone_transicao: def_cone_transicao.deleteMe()
        
        cmd_cone_transicao = ui.commandDefinitions.addButtonDefinition(
            cmd_cone_id, 
            'Cone por transição', 
            'Centro da base circular, Raio da base circular, Vértice',
            icon_cone
        )
        on_cone_transicao = GenericHandler(cone_transicao.run_cone_transicao)
        cmd_cone_transicao.commandCreated.add(on_cone_transicao)
        handlers.append(on_cone_transicao)     
        geo_panel.controls.addCommand(cmd_cone_transicao)
        
        #----------------- --- BOTÃO PARALELEPIPEDO ---  ---------------------------------------------------------------------------
        
        cmd_para_id = 'btnParalelepipedo'
        icon_paralelepipedo = os.path.join(base_path, 'resources', cmd_para_id)
        def_p = ui.commandDefinitions.itemById(cmd_para_id)
        if def_p: def_p.deleteMe()
        cmd_p = ui.commandDefinitions.addButtonDefinition(
            cmd_para_id, 
            'Paralelepípedo', 
            'Largura, Comprimento, Altura', 
            icon_paralelepipedo  # O Fusion entrará nesta pasta para buscar 16x16 e 32x32
        )
        on_p = GenericHandler(paralelepipedo.run_paralelepipedo)
        cmd_p.commandCreated.add(on_p)
        handlers.append(on_p)
        geo_panel.controls.addCommand(cmd_p)
        
        #-------------------------------------------------------------------------------------------------------------------------------
        
        
        #-------------------------------------------------------------------------------------------------------------------------------
        # --- BOTÃO: PIRÂMIDE POR TRANSIÇÃO (NOVO) ---
        cmd_piramide_transicao_id = 'btnPiramideTransicao'
        icon_piramide_transicao = os.path.join(base_path, 'resources', cmd_piramide_transicao_id)
        def_piramide_transicao = ui.commandDefinitions.itemById(cmd_piramide_transicao_id)
        if def_piramide_transicao: def_piramide_transicao.deleteMe()
        cmd_piramide_transicao = ui.commandDefinitions.addButtonDefinition(
            'btnPiramideTransicao', 
            'Pirâmide por transição', 
            'Núm. de arestas da base, Medida da base, Coordenadas do vértice',icon_piramide_transicao
        )
        on_piramide_transicao = GenericHandler(piramide_transicao.run_piramide)
        cmd_piramide_transicao.commandCreated.add(on_piramide_transicao)
        handlers.append(on_piramide_transicao)     
        geo_panel.controls.addCommand(cmd_piramide_transicao)
        
        # --- BOTÃO: CASCA ESFÉRICA (Ângulo Variável) ---
        cmd_casca_esferica_id = 'btnCascaEsf'
        icon_casca_esferica = os.path.join(base_path, 'resources', cmd_casca_esferica_id)
        def_casca = ui.commandDefinitions.itemById(cmd_casca_esferica_id)
        if def_casca: def_casca.deleteMe()
        cmd_casca = ui.commandDefinitions.addButtonDefinition(cmd_casca_esferica_id, 'Casca Esférica', 'Raio, Espessura e Ângulo', icon_casca_esferica)
        on_casca = GenericHandler(casca_esferica.run_casca)
        cmd_casca.commandCreated.add(on_casca)
        handlers.append(on_casca)
        geo_panel.controls.addCommand(cmd_casca)
        
                
        # --- BOTÃO: CASCA DE CILINDRO ---
        cmd_cil_id = 'btnCascaCilindro'
        icon_cil = os.path.join(base_path, 'resources', cmd_cil_id)
        
        def_cil = ui.commandDefinitions.itemById(cmd_cil_id)
        if def_cil: def_cil.deleteMe()
        
        cmd_cil = ui.commandDefinitions.addButtonDefinition(
            cmd_cil_id, 
            'Casca de Cilindro', 
            'Gera cilindro oco por raio e espessura',
            icon_cil
        )
        on_cil = GenericHandler(casca_cilindro.run_casca_cilindro)
        cmd_cil.commandCreated.add(on_cil)
        handlers.append(on_cil)
        geo_panel.controls.addCommand(cmd_cil)
        
        # --- BOTÃO: CASCA TRONCO DE CONE ---
        cmd_tronco_id = 'btnCascaTronco'
        icon_tronco = os.path.join(base_path, 'resources', cmd_tronco_id)
        
        def_tronco = ui.commandDefinitions.itemById(cmd_tronco_id)
        if def_tronco: def_tronco.deleteMe()
        
        cmd_tronco = ui.commandDefinitions.addButtonDefinition(
            cmd_tronco_id, 
            'Casca de Tronco', 
            'Raio da base, Altura, Raio do topo, Espessura',
            icon_tronco
        )
        on_tronco = GenericHandler(casca_tronco_cone.run_casca_tronco)
        cmd_tronco.commandCreated.add(on_tronco)
        handlers.append(on_tronco)
        geo_panel.controls.addCommand(cmd_tronco)
        
        # --- BOTÃO: CASCA DE PRISMA ---
        cmd_cprisma_id = 'btnCascaPrisma'
        icon_cprisma = os.path.join(base_path, 'resources', cmd_cprisma_id)
        
        def_cp = ui.commandDefinitions.itemById(cmd_cprisma_id)
        if def_cp: def_cp.deleteMe()
        
        cmd_cp = ui.commandDefinitions.addButtonDefinition(
            cmd_cprisma_id, 
            'Casca de Prisma', 
            'Núm. de arestas da base, Medida da base, Altura, Espessuras',
            icon_cprisma
        )
        on_cp = GenericHandler(casca_prisma.run_casca_prisma)
        cmd_cp.commandCreated.add(on_cp)
        handlers.append(on_cp)
        geo_panel.controls.addCommand(cmd_cp)
        
        # --- BOTÃO: CASCA DE PARALELEPÍPEDO ---
        cmd_cpara_id = 'btnCascaPara'
        icon_cpara = os.path.join(base_path, 'resources', cmd_cpara_id)
        
        def_cp = ui.commandDefinitions.itemById(cmd_cpara_id)
        if def_cp: def_cp.deleteMe()
        
        cmd_cp = ui.commandDefinitions.addButtonDefinition(
            cmd_cpara_id, 
            'Casca de Paralelepípedo', 
            'Largura, Comprimento, Altura, Espessuras',
            icon_cpara
        )
        on_cp = GenericHandler(casca_paralelepipedo.run_casca_para)
        cmd_cp.commandCreated.add(on_cp)
        handlers.append(on_cp)
        geo_panel.controls.addCommand(cmd_cp)
        
        # --- BOTÃO: CASCA DE CONE ---
        cmd_ccone_id = 'btnCascaCone'
        icon_ccone = os.path.join(base_path, 'resources', cmd_ccone_id)
        
        def_cc = ui.commandDefinitions.itemById(cmd_ccone_id)
        if def_cc: def_cc.deleteMe()
        
        cmd_cc = ui.commandDefinitions.addButtonDefinition(
            cmd_ccone_id, 
            'Casca de Cone', 
            'Gera cone oco por dimensões internas',
            icon_ccone
        )
        on_cc = GenericHandler(casca_cone.run_casca_cone)
        cmd_cc.commandCreated.add(on_cc)
        handlers.append(on_cc)
        geo_panel.controls.addCommand(cmd_cc)
        
    except:
        if ui: ui.messageBox('Erro no Run:\n{}'.format(traceback.format_exc()))

def stop(context):
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        workspace = ui.workspaces.itemById('FusionSolidEnvironment')
        panel = workspace.toolbarTabs.itemById('SolidTab').toolbarPanels.itemById('GeoEscolaPanel')
        if panel: panel.deleteMe()
    except: pass