import adsk.core, adsk.fusion, traceback

# Lista global para manter os handlers vivos na memória
_handlers = []

def run_paralelepipedo():
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        cmd_def = ui.commandDefinitions.itemById('cmd_para_geo')
        if cmd_def:
            cmd_def.deleteMe() 
        
        cmd_def = ui.commandDefinitions.addButtonDefinition('cmd_para_geo', 'Paralelepípedo', 'Gera um paralelepípedo reto')
        
        on_created = ParalelepipedoCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        
        cmd_def.execute()
    except:
        ui.messageBox('Erro ao iniciar: {}'.format(traceback.format_exc()))

class ParalelepipedoCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            # Usando commandInputs para estabilidade
            inputs = args.command.commandInputs

            # Caixas de entrada para as 3 dimensões (padrão 40x40x40 mm)
            inputs.addValueInput('largura', 'Largura: X', 'mm', adsk.core.ValueInput.createByReal(2.0))
            inputs.addValueInput('comprimento', 'Comprimento: Y', 'mm', adsk.core.ValueInput.createByReal(3.0))
            inputs.addValueInput('altura', 'Altura: Z', 'mm', adsk.core.ValueInput.createByReal(4.0))

            on_execute = ParalelepipedoExecuteHandler()
            args.command.execute.add(on_execute)
            _handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na interface: {}'.format(traceback.format_exc()))

class ParalelepipedoExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            inputs = args.command.commandInputs

            # Captura das medidas
            larg = inputs.itemById('largura').value
            comp = inputs.itemById('comprimento').value
            alt = inputs.itemById('altura').value

            design = adsk.fusion.Design.cast(app.activeProduct)
            root = design.rootComponent
            
            # 1. Criar o Sketch no plano XY
            sketches = root.sketches
            plane = root.xYConstructionPlane
            sketch = sketches.add(plane)
            
            # 2. Desenhar o retângulo da base (Vértice 1 na Origem 0,0,0)
            lines = sketch.sketchCurves.sketchLines
            ponto_origem = adsk.core.Point3D.create(0, 0, 0)
            ponto_oposto = adsk.core.Point3D.create(larg, comp, 0)
            lines.addTwoPointRectangle(ponto_origem, ponto_oposto)
            
            # 3. Extrusão para dar a altura (Z)
            prof = sketch.profiles.item(0)
            extrudes = root.features.extrudeFeatures
            ext_input = extrudes.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            ext_input.setDistanceExtent(False, adsk.core.ValueInput.createByReal(alt))
            extrudes.add(ext_input)
            
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na Geometria: {}'.format(traceback.format_exc()))