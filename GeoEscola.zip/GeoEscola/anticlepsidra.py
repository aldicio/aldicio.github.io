import adsk.core, adsk.fusion, traceback
import math

# Lista global para manter os handlers vivos
_handlers = []

def run_anticlepsidra():
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        cmd_id = 'cmd_anticlepsidra'
        cmd_def = ui.commandDefinitions.itemById(cmd_id)
        if cmd_def: cmd_def.deleteMe() 
        
        cmd_def = ui.commandDefinitions.addButtonDefinition(
            cmd_id, 
            'Anticlepsidra', 
            'Gera um sólido com dois cones invertidos subtraídos de um cilindro'
        )
        
        on_created = AnticlepsidraCreatedHandler()
        cmd_def.commandCreated.add(on_created)
        _handlers.append(on_created)
        
        cmd_def.execute()
    except:
        ui.messageBox('Erro ao iniciar Anticlepsidra: {}'.format(traceback.format_exc()))

class AnticlepsidraCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            
            # Parâmetros em mm (API utiliza cm, então multiplicamos por 10 na interface se necessário, 
            # mas manteremos a lógica de cm internamente como no original)
            inputs.addValueInput('raio', 'Raio Interno', 'mm', adsk.core.ValueInput.createByReal(5.0))
            inputs.addValueInput('esp_parede', 'Espessura da parede', 'mm', adsk.core.ValueInput.createByReal(0.2))
            inputs.addValueInput('esp_tampa', 'Espessura da tampa', 'mm', adsk.core.ValueInput.createByReal(0.3))
            inputs.addValueInput('esp_fundo', 'Espessura do fundo', 'mm', adsk.core.ValueInput.createByReal(0.3))

            on_execute = AnticlepsidraExecuteHandler()
            args.command.execute.add(on_execute)
            _handlers.append(on_execute)
        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na interface: {}'.format(traceback.format_exc()))

class AnticlepsidraExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            app = adsk.core.Application.get()
            inputs = args.command.commandInputs
            
            # Resgate dos valores (API do Fusion entrega em cm)
            r = inputs.itemById('raio').value
            e_p = inputs.itemById('esp_parede').value
            e_t = inputs.itemById('esp_tampa').value
            e_f = inputs.itemById('esp_fundo').value
            
            design = adsk.fusion.Design.cast(app.activeProduct)
            rootComp = design.rootComponent
            features = rootComp.features
            combineFeatures = features.combineFeatures

            # 1. CILINDRO EXTERIOR
            skExt = rootComp.sketches.add(rootComp.xYConstructionPlane)
            skExt.sketchCurves.sketchCircles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), r + e_p)
            
            extInput = features.extrudeFeatures.createInput(skExt.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            altura_total = (2 * r) + e_f + e_t
            extInput.setDistanceExtent(False, adsk.core.ValueInput.createByReal(altura_total))
            corpoFinal = features.extrudeFeatures.add(extInput).bodies.item(0)

            # 2. VOLUME INTERNO (O "OCO")
            skInt = rootComp.sketches.add(rootComp.xYConstructionPlane)
            skInt.sketchCurves.sketchCircles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), r)
            
            extInputInt = features.extrudeFeatures.createInput(skInt.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            extInputInt.startExtent = adsk.fusion.OffsetStartDefinition.create(adsk.core.ValueInput.createByReal(e_f))
            extInputInt.setDistanceExtent(False, adsk.core.ValueInput.createByReal(2 * r))
            corpoVazioInterno = features.extrudeFeatures.add(extInputInt).bodies.item(0)

            # 3. CONES INTERNOS
            z_encontro = r + e_f
            pontoEncontro = rootComp.sketches.add(rootComp.xYConstructionPlane).sketchPoints.add(adsk.core.Point3D.create(0,0, z_encontro))
            
            lofts = features.loftFeatures
            
            # Cone Superior
            skTop = rootComp.sketches.add(rootComp.xYConstructionPlane)
            skTop.sketchCurves.sketchCircles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 2*r + e_f), r)
            loft1 = lofts.createInput(adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            loft1.loftSections.add(skTop.profiles.item(0))
            loft1.loftSections.add(pontoEncontro)
            cone1 = lofts.add(loft1).bodies.item(0)

            # Cone Inferior
            skBottom = rootComp.sketches.add(rootComp.xYConstructionPlane)
            skBottom.sketchCurves.sketchCircles.addByCenterRadius(adsk.core.Point3D.create(0, 0, e_f), r)
            loft2 = lofts.createInput(adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            loft2.loftSections.add(skBottom.profiles.item(0))
            loft2.loftSections.add(pontoEncontro)
            cone2 = lofts.add(loft2).bodies.item(0)

            # 4. OPERAÇÕES BOOLEANAS
            toolsParaVazio = adsk.core.ObjectCollection.create()
            toolsParaVazio.add(cone1)
            toolsParaVazio.add(cone2)
            combineVazioInput = combineFeatures.createInput(corpoVazioInterno, toolsParaVazio)
            combineVazioInput.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
            combineFeatures.add(combineVazioInput)

            toolsParaCorpo = adsk.core.ObjectCollection.create()
            toolsParaCorpo.add(corpoVazioInterno)
            combineFinalInput = combineFeatures.createInput(corpoFinal, toolsParaCorpo)
            combineFinalInput.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
            combineFeatures.add(combineFinalInput)

        except:
            adsk.core.Application.get().userInterface.messageBox('Erro na Geometria: {}'.format(traceback.format_exc()))